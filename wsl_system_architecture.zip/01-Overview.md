# Overview

Windows Subsystem for Linux (WSL) allows Linux binaries to run natively on Windows.
Internally, WSL consists of a mix of Windows services, kernel components, and
virtualization infrastructure that differs significantly between WSL1 and WSL2.

This documentation describes the internal architecture of WSL with a focus on
filesystem behavior, Windows–Linux integration, and process lifecycles.

## Documentation Structure

- [WSL1 Architecture](02-WSL1-Architecture.md)  
  Translation-based compatibility layer and NT kernel integration.

- [WSL2 Architecture](03-WSL2-Architecture.md)  
  Virtual machine–based architecture using a real Linux kernel.

- [Windows-Side Components](04-Windows-Side-Components.md)  
  High-level overview of Windows services and processes involved in WSL.

- [wslservice and LxssManager](05-wslservice-and-lxssmanager.md)  
  Control-plane services responsible for distribution lifecycle and orchestration.

- [wslhost Runtime Bridge](06-wslhost-runtime-bridge.md)  
  Runtime communication bridge between Windows and the WSL2 virtual machine.

- [How Everything Works Together](07-How-Everything-Works-Together.md)  
  End-to-end flow covering startup, execution, and filesystem access.

- [Key Points](08-Key-Points.md)  
  Summary of architectural takeaways and important behaviors.

The intent is to provide a **system-level understanding** of WSL internals rather
than user-facing configuration guidance.
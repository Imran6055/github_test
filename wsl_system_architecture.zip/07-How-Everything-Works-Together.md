# How Everything Works Together

End-to-end flow of starting and running a WSL2 distribution.

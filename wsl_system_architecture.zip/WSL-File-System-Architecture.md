# WSL FileSystem Architecture

WSL has two different architectures, and the storage mechanism is different for each.
Understanding WSL storage means understanding the difference between WSL1 vs WSL2.

![alt text](File_Architecture_WSL.png)

## WSL1 (translation layer)

- Stores Linux files directly in NTFS (no virtual disk), historically under **%LOCALAPPDATA%\lxss\….**

- Windows–Linux interop is via a translation layer, giving faster access to Windows files but slower pure Linux FS operations.

## How WSL1 Emulates Linux Filesystem
WSL1 does not use ext4.
It simulates Linux using:

- NTFS + metadata translation
- A kernel driver: `lxcore.sys`
- A user‑space manager: `lxssmanager.dll`

WSL1 stores Linux permissions using NTFS extended attributes (EA).
Windows attributes like: `LXATTRIB, LXUID, LXGID` are hidden NTFS metadata blobs that represent:

* chmod
* chown
* timestamps
* symlink types

This is why:

WSL1 symlinks sometimes break **chmod +x** doesn’t behave like real `ext4`. Tarballs extracted in WSL1 may lose metadata


# WSL2 (lightweight VM)

- Stores Linux files inside a native ext4 filesystem within ext4.vhdx per distro, typically at:
`%LOCALAPPDATA%\Packages\<DistroPackage>\LocalState\ext4.vhdx`
- The VHDX dynamically expands (recent default max ~1TB), but it doesn’t shrink automatically—compaction/export‑import is needed. 
- Access from Windows uses the \\wsl$\<Distro>\ UNC (Universal Naming Convension) path and a 9P (Plan9) fileserver under the hood for Windows↔Linux filesystem bridging

## Performance Characteristics

WSL2 File Performance Characteristics: 

* Fast inside ext4.vhdx
* Slower accessing Windows files via /mnt/c due to 9P protocol overhead
* WSL1 is faster than WSL2 for Windows file access
* `/mnt/c` access → FAST (native Windows filesystem)
* Linux FS access (/home, /usr) → SLOW, because it's NTFS emulation
* Compiling large projects → slower

### Cross‑filesystem Behavior

- Case sensitivity emulated
- Some filenames illegal on Windows (con, aux, etc.) → cause issues
- Symlink behavior does not match real Linux precisely

## How FileSystem Emulates in WSL2 
* Each WSL2 distro is stored inside a VHDX virtual disk, located at: `%LOCALAPPDATA%\Packages\<DistroPackage>\LocalState\ext4.vhdx`

* Full Linux ext4 filesystem Houses: **/home, /etc, /usr, /var, /root**

* Behaves like a standard Linux disk, dynamically expands until default max 1 TB in modern WSL.

### VHDX Behavior (Dynamic Sizing & Shrinking)
WSL2 disks grow automatically but never shrink on their own, even after deleting files.
To reclaim disk space, you must optimize the VHDX.

**Options to shrink:**

* Export/import the WSL distro - most effective (as we seen how to export/import distro in previous guides)
* Optimize-VHD (when WSL2 is stopped)
* Using Diskpart to clean unused space

This is one of the most misunderstood aspects of WSL2.
## Optimizing VHD

**very important:** Make sure WSL not running. If not, type `wsl --shutdown` on your terminal to shutdown WSL.
In order to optimize ext4.vhd and clear unused spaces. You need to enable **Hyper-V management feature**, enabling Hyper-V automatically enables the feature on your system. If not enabled not, open PowerShell as an Administrator and run:

`Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All`.
This command enables all Hyper-V components, including management tools and the PowerShell module 

You can enable the same by heading over to **Control Panel → Programs → Turn Windows features on or off**. You need to `enable Hyper-V` as shown on the image below.

![alt text](<Screenshot 2026-01-18 144954.png>)

Once enabled, reboot the system to make the setting take effect.

After rebooting the system, open the powershell as administarator and type this command 

`get-command Optimize-vhd` 

![alt text](image-27.png)

The following output confirms **optimize-vhd** enabled successfully.


on the powershell type:
`Optimize-VHD -Path "C:\Users\<User>\AppData\Local\Packages\<DistroName>\LocalState\ext4.vhdx" -Mode Full`

![alt text](<Screenshot 2026-01-18 154211.png>)

**Mode explanation:**

- Full → Maximum shrink
- Quick → Small cleanup

## Another Method: Using DiskPart to optimize vhd

**Note:**: Be cautious when using `Diskpart` command. 

* WSL must be fully shut down
* The VHDX must not be mounted by WSL
* No Linux processes should be running

Find your ext4.vhdx file
Default path:
`%LOCALAPPDATA%\Packages\<Distro>\LocalState\ext4.vhdx`

example:
`C:\Users\YourName\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc\LocalState\ext4.vhdx`

1. Open Diskpart in powershell as an administrator
2. enter the command: `select vdisk file="C:\Users\YourName\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu_22.04\LocalState\ext4.vhdx"`
3. Next enter `compact vdisk`.

![alt text](image-24.png)

The following output confirms vhd optimized successfully.


Linux Native Mounts via **wsl --mount**
WSL2 can mount real Linux disks:
`wsl --mount <Disk> --partition <n> --type ext4`

WSL mount Supports: **ext4,xfs,btrfs filesystems**
This bypasses Windows NTFS entirely.

### 9P fileserver (\\wsl$) 

9P (or the Plan 9 Filesystem Protocol) is a network protocol developed for the Plan 9 from Bell Labs distributed operating system as the means of connecting the components of a Plan 9 system. Files are key objects in Plan 9. They represent windows, network connections, processes, and almost anything else available in the operating system.

WSL2 uses a 9P protocol server running inside the VM.
Windows accesses Linux files using:

`\\wsl$\<distro_name>\`

This is how Explorer, VS Code, and Windows apps access WSL files.

**Important:**
9P is the main reason Windows → Linux file operations are slower in WSL2.

## Symlink and Case‑Sensitivity Rules
WSL translations:

![alt text](image-25.png)

## Registry Internals

All distro metadata is stored here:

`HKCU\Software\Microsoft\Windows\CurrentVersion\Lxss`

![alt text](image-26.png)

Each distro has:

* BasePath → path to where its VHDX lives
* DistributionName
* Version (1 or 2)
* Unique GUID for each distro

## WSLg Filesystems
WSLg is the subsystem of WSL that enables Linux GUI applications (both X11 and Wayland) to run on Windows with full desktop integration—without needing a separate X‑server, VNC, or VM. 

WSLg adds special mounts:
`/mnt/wsl`
`/mnt/wslg`
`/run/WSL`

These include:

* Wayland socket
* X11 socket
* PulseAudio
* Shared memory (VirtIO-based)

We will see more about Wslg in a separate section.

# Points to Remember

1. WSL2 uses Plan9 FS (9P) to communicate with Windows
   This enables \\wsl$ UNC paths.
2. WSL1 stores Linux file metadata in NTFS Extended Attributes
   This emulates chmod, chown, stat, etc.
3. ext4.vhdx uses sparse allocation. Deleting files does not release disk space         automatically.
4. WSL2 networking is NAT'd through a virtual switch. It has its own IP and virtual NIC.
5. Each distro is isolated (separate kernel namespaces). Their filesystems and users do not mix.
6. WSLg uses a full Weston compositor. Running inside WSL2 with **RDP-based** transport.
7. Docker Desktop stores containers in a hidden WSL2 distro
   Path example:
`C:\Users\<User>\AppData\Local\Docker\wsl\`

8. WSL2 supports passthrough mounting of physical Linux disks. Even encrypted LUKS(used for encryption) disks works after unlocking externally.
9. /mnt/c uses a FUSE-like mechanism called DrvFs. It's not a kernel filesystem.






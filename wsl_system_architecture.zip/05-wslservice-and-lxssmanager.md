# wslservice and LxssManager

Control-plane services responsible for WSL distribution lifecycle management.

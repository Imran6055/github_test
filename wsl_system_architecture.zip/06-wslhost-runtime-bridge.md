# wslhost Runtime Bridge

Runtime communication bridge between Windows and the WSL2 virtual machine.

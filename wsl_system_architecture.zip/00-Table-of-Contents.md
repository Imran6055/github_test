# WSL File System Architecture – Table of Contents

This documentation describes the internal architecture of Windows Subsystem for Linux (WSL),
with a focus on filesystem behavior, Windows-side components, and execution flow.

## Introduction
- [Overview](01-Overview.md)

## Architecture
- [WSL1 Architecture](02-WSL1-Architecture.md)
- [WSL2 Architecture](03-WSL2-Architecture.md)

## Windows-Side Components
- [Windows-Side Components](04-Windows-Side-Components.md)
- [wslservice and LxssManager](05-wslservice-and-lxssmanager.md)
- [wslhost Runtime Bridge](06-wslhost-runtime-bridge.md)

## End-to-End Flow
- [How Everything Works Together](07-How-Everything-Works-Together.md)

## Summary
- [Key Points](08-Key-Points.md)

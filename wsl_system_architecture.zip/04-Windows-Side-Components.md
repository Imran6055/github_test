# Windows-Side Components

High-level overview of Windows services and processes that support WSL.

# WSL1 Architecture

WSL1 provides a translation-based compatibility layer that allows Linux binaries
to execute directly on the Windows kernel without virtualization.

## Key Characteristics

- No virtual machine
- Linux syscalls translated into Windows NT kernel calls
- Files stored directly on NTFS
- Tight integration with the Windows filesystem

## Core Components

- lxss.sys – syscall translation driver
- lxcore.sys – Linux kernel interface
- LXCoreManager.dll – user-mode coordination
- pico processes – lightweight process model

## Filesystem Behavior

Linux files are mapped directly to NTFS paths under the user profile.
Access from both Windows and Linux is immediate, but performance and
case-sensitivity behavior differs from native Linux filesystems.

WSL1 prioritizes compatibility and integration over strict Linux semantics.

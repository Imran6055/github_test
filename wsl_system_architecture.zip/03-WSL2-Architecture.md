# WSL2 Architecture

# WSL2 Architecture

WSL2 uses a lightweight virtual machine running a real Linux kernel.
This architecture provides full system call compatibility and improved
Linux filesystem behavior.

## Key Characteristics

- Real Linux kernel
- Lightweight VM managed by Windows
- Virtualized filesystem (ext4 inside VHDX)
- Improved syscall compatibility

## Core Components

- Linux kernel (Microsoft-maintained)
- Utility VM
- Virtual disk (VHDX)
- Hyper-V based isolation

## Filesystem Behavior

Linux files are stored inside an ext4 filesystem within a VHDX file.
This improves Linux compatibility and performance for Linux-native workloads,
while cross-filesystem access is handled via proxy mechanisms.

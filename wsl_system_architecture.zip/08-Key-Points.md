# Key Points

- WSL1 and WSL2 have fundamentally different architectures
- WSL1 translates syscalls; WSL2 runs a real Linux kernel
- Windows-side services control lifecycle and configuration
- wslhost is central to Windows–Linux communication
- Filesystem performance depends heavily on access direction

Understanding these components helps diagnose performance issues,
resource usage, and unexpected behavior.
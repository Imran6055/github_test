# wslservice and LxssManager

Control-plane services managing WSL lifecycle.

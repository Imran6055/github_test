# wslhost Runtime Bridge

Runtime bridge between Windows and WSL2 VM.

# Overview

Windows Subsystem for Linux (WSL) allows Linux binaries to run natively on Windows.
Internally, WSL consists of a mix of Windows services, kernel components, and
virtualization infrastructure that differs significantly between WSL1 and WSL2.

This documentation describes the internal architecture of WSL with a focus on
filesystem behavior, Windows–Linux integration, and process lifecycles.

## Documentation Structure

- [WSL1 Architecture](02-WSL1-Architecture.md)
- [WSL2 Architecture](03-WSL2-Architecture.md)
- [Windows-Side Components](04-Windows-Side-Components.md)
- [wslservice and LxssManager](05-wslservice-and-lxssmanager.md)
- [wslhost Runtime Bridge](06-wslhost-runtime-bridge.md)
- [How Everything Works Together](07-How-Everything-Works-Together.md)
- [Key Points](08-Key-Points.md)

# WSL1 Architecture

WSL1 provides a syscall translation layer without virtualization.

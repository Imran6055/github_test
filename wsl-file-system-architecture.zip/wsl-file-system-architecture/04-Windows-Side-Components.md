# Windows-Side Components

Overview of Windows-side WSL services and processes.

# WSL2 Architecture

WSL2 uses a lightweight VM with a real Linux kernel.

# Filesystem Interoperability and 9P

## /mnt/c
Uses DrvFs (FUSE-like filesystem)

## \\wsl$
Access Linux files from Windows

## 9P Protocol
Used for Windows ↔ Linux filesystem access

# WSL2 File System Architecture

WSL2 runs a real Linux kernel inside a lightweight VM.

## Storage Model
Each distro uses an ext4 filesystem stored in:
%LOCALAPPDATA%\Packages\<Distro>\LocalState\ext4.vhdx

## Layout
/home, /etc, /usr, /var, /root

## Disk Behavior
- Dynamic growth
- No automatic shrinking

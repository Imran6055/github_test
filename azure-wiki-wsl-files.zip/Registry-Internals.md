# WSL Registry Internals

Location:
HKCU\Software\Microsoft\Windows\CurrentVersion\Lxss

Contains:
- BasePath
- DistributionName
- Version
- GUID

# WSL File System Architecture

This documentation explains how Windows Subsystem for Linux (WSL) stores,
exposes, and interoperates with Linux filesystems across WSL1 and WSL2.

## Topics Covered
- [WSL1 File System Architecture](WSL1-Architecture)
- [WSL2 File System Architecture](WSL2-Architecture)
- [WSL2 File Performance Characteristics](WSL2-File-Performance)
- [Filesystem Interoperability and 9P](FileSystem-Interop-9P)
- [VHDX Storage Behavior and Optimization](VHDX-Storage-Optimization)
- [Registry Internals](Registry-Internals)
- [WSLg Filesystems](WSLg-Filesystems)

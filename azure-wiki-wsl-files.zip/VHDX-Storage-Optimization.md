# VHDX Storage Optimization

## Important
WSL must be shut down:
wsl --shutdown

## Optimize-VHD
Requires Hyper-V management tools

Optimize-VHD -Path <ext4.vhdx> -Mode Full

## DiskPart
Use compact vdisk carefully

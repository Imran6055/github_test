# WSLg Filesystems

Special mounts:
/mnt/wsl
/mnt/wslg
/run/WSL

Includes Wayland, X11, PulseAudio, shared memory.

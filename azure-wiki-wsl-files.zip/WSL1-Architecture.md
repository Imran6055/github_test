# WSL1 File System Architecture

WSL1 uses a translation layer instead of a virtual machine.
Linux system calls are translated into Windows system calls.

## Storage Model
- Files stored directly on NTFS
- No virtual disk
- Default path:
%LOCALAPPDATA%\lxss\

## Filesystem Emulation
- NTFS metadata translation
- Kernel driver: lxcore.sys
- User-space manager: lxssmanager.dll

### Limitations
- Symlink issues
- chmod not fully POSIX compliant
- Metadata loss in archives

# WSL2 File Performance

## ext4.vhdx
- Fast Linux-native performance

## /mnt/c
- Slower due to 9P overhead

## Summary
- WSL1 faster for Windows files
- WSL2 faster for Linux workloads
